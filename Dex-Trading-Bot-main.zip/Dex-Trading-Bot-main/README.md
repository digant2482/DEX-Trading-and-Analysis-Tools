Uniswap trading bot for Uniswap V2 and V3, can be modified for almost any dex on ethereum blockchain.
